@file:OptIn(ExperimentalMaterial3Api::class)

package com.familypulse.app.ui.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlaylistAddCheck
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.outlined.PendingActions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.familypulse.app.data.FirebaseRepository
import com.familypulse.app.ui.theme.FamilyPulseLogo
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

private data class DashboardState(
    val userName: String = "Family Member",
    val familyId: String = "",
    val memberCount: Int = 0,
    val pendingTasks: Int = 0,
    val completedTasks: Int = 0,
    val checkedInToday: Boolean = false
)

@Composable
fun DashboardScreen(
    repo: FirebaseRepository,
    onLogout: () -> Unit,
    onNavigateToTasks: () -> Unit,
    onNavigateToCheckIn: () -> Unit,
    onNavigateToPairing: () -> Unit,
    onNavigateToMembers: () -> Unit,
    onNavigateToProfile: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val scope = rememberCoroutineScope()

    var state by remember { mutableStateOf(DashboardState()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    fun refresh() {
        scope.launch {
            loading = true
            error = null

            try {
                val uid = repo.getCurrentUser()?.uid

                if (uid != null) {
                    val profile = repo.getUserProfile(uid)
                    val familyId = profile?.familyId.orEmpty()

                    var memberCount = 0
                    var pending = 0
                    var completed = 0
                    var checkedInToday = false

                    if (familyId.isNotBlank()) {
                        memberCount = repo.getFamilyMembers(familyId).size

                        val taskDocs = repo.getTasks(familyId).get().await()
                        pending = taskDocs.documents.count {
                            it.getBoolean("isCompleted") != true
                        }
                        completed = taskDocs.documents.count {
                            it.getBoolean("isCompleted") == true
                        }

                        val checkInDocs = repo.getCheckIns(familyId).get().await()
                        val startOfDay = run {
                            val cal = java.util.Calendar.getInstance()
                            cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
                            cal.set(java.util.Calendar.MINUTE, 0)
                            cal.set(java.util.Calendar.SECOND, 0)
                            cal.set(java.util.Calendar.MILLISECOND, 0)
                            cal.timeInMillis
                        }
                        checkedInToday = checkInDocs.documents.any { doc ->
                            doc.getString("userId") == uid &&
                                (doc.getLong("timestamp") ?: 0L) >= startOfDay
                        }
                    }

                    state = DashboardState(
                        userName = profile?.name?.ifBlank { "Family Member" } ?: "Family Member",
                        familyId = familyId,
                        memberCount = memberCount,
                        pendingTasks = pending,
                        completedTasks = completed,
                        checkedInToday = checkedInToday
                    )
                } else {
                    error = "Please log in again."
                }
            } catch (e: Exception) {
                error = e.message ?: "Could not load your dashboard."
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) { refresh() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {},
                actions = {
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                FamilyPulseLogo(size = 52.dp)

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        "Hi, ${state.userName.substringBefore(" ")} 👋",
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text(
                        "Here's what's happening today",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            when {
                loading -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 60.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }

                error != null -> {
                    ErrorCard(message = error!!, onRetry = { refresh() })
                }

                state.familyId.isBlank() -> {
                    NotPairedCard(onNavigateToPairing = onNavigateToPairing)
                }

                else -> {
                    FamilyStatusCard(
                        familyId = state.familyId,
                        memberCount = state.memberCount,
                        checkedInToday = state.checkedInToday
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier.height(170.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(
                            listOf(
                                Triple("Members", state.memberCount.toString(), Icons.Filled.Group),
                                Triple("Pending", state.pendingTasks.toString(), Icons.Outlined.PendingActions),
                                Triple("Completed", state.completedTasks.toString(), Icons.Filled.CheckCircle),
                                Triple(
                                    "Check-in",
                                    if (state.checkedInToday) "Done" else "Pending",
                                    Icons.Filled.TaskAlt
                                )
                            )
                        ) { (label, value, icon) ->
                            StatCard(label = label, value = value, icon = icon)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text("Quick Actions", style = MaterialTheme.typography.titleLarge)

            Spacer(modifier = Modifier.height(10.dp))

            DashboardButton(
                icon = Icons.Filled.Group,
                title = "Family Members",
                subtitle = "See everyone connected to your family",
                onClick = onNavigateToMembers
            )

            DashboardButton(
                icon = Icons.Filled.PlaylistAddCheck,
                title = "Family Tasks",
                subtitle = "Create and manage shared tasks",
                onClick = onNavigateToTasks
            )

            DashboardButton(
                icon = Icons.Filled.TaskAlt,
                title = "Daily Check-In",
                subtitle = "Share a voluntary status update",
                onClick = onNavigateToCheckIn
            )

            DashboardButton(
                icon = Icons.Filled.Link,
                title = "Family Pairing",
                subtitle = "Create or join a family",
                onClick = onNavigateToPairing
            )

            DashboardButton(
                icon = Icons.Filled.Person,
                title = "My Profile",
                subtitle = "View your account and family information",
                onClick = onNavigateToProfile
            )

            Spacer(modifier = Modifier.height(6.dp))

            TextButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) {
                Text("Logout")
            }

            Text(
                "Privacy-first family coordination. No hidden monitoring.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }
    }
}

@Composable
private fun FamilyStatusCard(
    familyId: String,
    memberCount: Int,
    checkedInToday: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "Family connected",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        "Code: $familyId",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                AssistChip(
                    onClick = {},
                    enabled = false,
                    label = { Text("$memberCount member${if (memberCount == 1) "" else "s"}") }
                )
            }
        }
    }
}

@Composable
private fun NotPairedCard(onNavigateToPairing: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("You haven't joined a family yet", style = MaterialTheme.typography.titleLarge)

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                "Create a family or join one with a 6-digit code to start sharing tasks and check-ins.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            Button(onClick = onNavigateToPairing, modifier = Modifier.fillMaxWidth()) {
                Text("Set Up Family")
            }
        }
    }
}

@Composable
private fun ErrorCard(message: String, onRetry: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer
        )
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                message,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedButton(onClick = onRetry) {
                Text("Try Again")
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, icon: ImageVector) {
    Card(
        modifier = Modifier.fillMaxSize(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun DashboardButton(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(42.dp),
                shape = CircleShape,
                color = MaterialTheme.colorScheme.secondaryContainer
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Text("›", style = MaterialTheme.typography.headlineMedium)
        }
    }
}
