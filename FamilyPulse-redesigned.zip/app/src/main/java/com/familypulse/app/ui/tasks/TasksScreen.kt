@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.familypulse.app.ui.tasks

import android.app.DatePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.familypulse.app.data.FirebaseRepository
import com.familypulse.app.models.FamilyTask
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val PRIORITIES = listOf("Low", "Normal", "High")

@Composable
fun TasksScreen(
    repo: FirebaseRepository,
    familyId: String,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("Normal") }
    var dueDate by remember { mutableStateOf<Long?>(null) }

    var tasks by remember { mutableStateOf<List<FamilyTask>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var listLoading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var showForm by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<FamilyTask?>(null) }

    fun loadTasks() {
        if (familyId.isBlank()) {
            listLoading = false
            return
        }

        listLoading = true

        repo.getTasks(familyId)
            .get()
            .addOnSuccessListener { result ->
                tasks = result.documents.mapNotNull { document ->
                    document.toObject(FamilyTask::class.java)?.copy(id = document.id)
                }.sortedWith(compareBy({ it.isCompleted }, { it.dueDate.let { d -> if (d == 0L) Long.MAX_VALUE else d } }))
                listLoading = false
            }
            .addOnFailureListener {
                error = it.message ?: "Could not load tasks."
                listLoading = false
            }
    }

    LaunchedEffect(familyId) { loadTasks() }

    fun resetForm() {
        title = ""
        description = ""
        priority = "Normal"
        dueDate = null
        showForm = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Family Tasks") },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } }
            )
        },
        floatingActionButton = {
            if (familyId.isNotBlank() && !showForm) {
                FloatingActionButton(onClick = { showForm = true }) {
                    Icon(Icons.Filled.Add, contentDescription = "Add task")
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp)
        ) {
            if (familyId.isBlank()) {
                Spacer(modifier = Modifier.height(16.dp))
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Family is not paired yet.", style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Pair your account before creating family tasks.")
                    }
                }
            } else {

            Spacer(modifier = Modifier.height(12.dp))

            TaskStatsRow(
                pending = tasks.count { !it.isCompleted },
                completed = tasks.count { it.isCompleted }
            )

            Spacer(modifier = Modifier.height(14.dp))

            if (showForm) {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("New Task", style = MaterialTheme.typography.titleMedium)

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = title,
                            onValueChange = { title = it; error = "" },
                            label = { Text("Task Title") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = description,
                            onValueChange = { description = it; error = "" },
                            label = { Text("Description (optional)") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text("Priority", style = MaterialTheme.typography.labelLarge)
                        Spacer(modifier = Modifier.height(6.dp))

                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PRIORITIES.forEach { level ->
                                FilterChip(
                                    selected = priority == level,
                                    onClick = { priority = level },
                                    label = { Text(level) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedButton(
                            onClick = {
                                val calendar = Calendar.getInstance()
                                DatePickerDialog(
                                    context,
                                    { _, year, month, day ->
                                        val picked = Calendar.getInstance()
                                        picked.set(year, month, day, 0, 0, 0)
                                        dueDate = picked.timeInMillis
                                    },
                                    calendar.get(Calendar.YEAR),
                                    calendar.get(Calendar.MONTH),
                                    calendar.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Filled.CalendarToday, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                dueDate?.let {
                                    "Due " + SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(it))
                                } ?: "Set due date (optional)"
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(
                                onClick = { resetForm() },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Cancel")
                            }

                            Button(
                                onClick = {
                                    if (title.isBlank()) {
                                        error = "Please enter a task title."
                                        return@Button
                                    }

                                    loading = true
                                    error = ""

                                    scope.launch {
                                        try {
                                            repo.addTask(
                                                familyId = familyId,
                                                task = FamilyTask(
                                                    title = title.trim(),
                                                    description = description.trim(),
                                                    isCompleted = false,
                                                    priority = priority,
                                                    dueDate = dueDate ?: 0L
                                                )
                                            )
                                            resetForm()
                                            loadTasks()
                                        } catch (e: Exception) {
                                            error = e.message ?: "Could not add task."
                                        } finally {
                                            loading = false
                                        }
                                    }
                                },
                                enabled = !loading,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (loading) "Adding..." else "Add Task")
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
            }

            if (error.isNotEmpty()) {
                Text(text = error, color = MaterialTheme.colorScheme.error)
                Spacer(modifier = Modifier.height(10.dp))
            }

            when {
                listLoading -> {
                    Box(modifier = Modifier.fillMaxWidth().padding(vertical = 40.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }

                tasks.isEmpty() -> {
                    Box(
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("No tasks yet", style = MaterialTheme.typography.titleMedium)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Tap + to add your family's first task.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                else -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        contentPadding = PaddingValues(bottom = 20.dp)
                    ) {
                        items(items = tasks, key = { it.id }) { task ->
                            TaskCard(
                                task = task,
                                onComplete = {
                                    tasks = tasks.map { if (it.id == task.id) it.copy(isCompleted = true) else it }
                                    repo.getTasks(familyId).document(task.id).update("isCompleted", true)
                                        .addOnFailureListener { error = it.message ?: "Could not save completed task." }
                                },
                                onMarkPending = {
                                    tasks = tasks.map { if (it.id == task.id) it.copy(isCompleted = false) else it }
                                    repo.getTasks(familyId).document(task.id).update("isCompleted", false)
                                        .addOnFailureListener { error = it.message ?: "Could not update task." }
                                },
                                onDelete = { pendingDelete = task }
                            )
                        }
                    }
                }
            }
            }
        }
    }

    pendingDelete?.let { task ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Delete task?") },
            text = { Text("\"${task.title}\" will be removed for the whole family. This can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        try {
                            repo.deleteTask(familyId = familyId, taskId = task.id)
                            tasks = tasks.filter { it.id != task.id }
                        } catch (e: Exception) {
                            error = e.message ?: "Could not delete task."
                        } finally {
                            pendingDelete = null
                        }
                    }
                }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun TaskStatsRow(pending: Int, completed: Int) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(pending.toString(), style = MaterialTheme.typography.headlineSmall)
                Text("Pending", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Card(modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(completed.toString(), style = MaterialTheme.typography.headlineSmall)
                Text("Completed", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun TaskCard(
    task: FamilyTask,
    onComplete: () -> Unit,
    onMarkPending: () -> Unit,
    onDelete: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), shape = RoundedCornerShape(16.dp)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )

                PriorityChip(task.priority)
            }

            if (task.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(5.dp))
                Text(task.description, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            if (task.dueDate > 0L) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    "Due " + SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(task.dueDate)),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                if (task.isCompleted) {
                    AssistChip(onClick = onMarkPending, label = { Text("Mark Pending") })
                } else {
                    Button(onClick = onComplete) { Text("Complete") }
                }

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, contentDescription = "Delete task")
                }
            }

            if (task.isCompleted) {
                Spacer(modifier = Modifier.height(4.dp))
                Text("✓ Completed", color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun PriorityChip(priority: String) {
    val (container, content) = when (priority) {
        "High" -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.onErrorContainer
        "Low" -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
        else -> MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.onSecondaryContainer
    }

    Surface(shape = RoundedCornerShape(50), color = container) {
        Text(
            priority,
            color = content,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}
