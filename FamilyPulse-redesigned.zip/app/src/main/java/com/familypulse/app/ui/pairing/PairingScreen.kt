@file:OptIn(ExperimentalMaterial3Api::class)

package com.familypulse.app.ui.pairing

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.familypulse.app.data.FirebaseRepository
import com.familypulse.app.models.UserProfile
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

private enum class PairingTab { JOIN, CREATE }

@Composable
fun PairingScreen(
    repo: FirebaseRepository,
    onPairingComplete: (UserProfile) -> Unit,
    onBack: () -> Unit
) {
    var tab by remember { mutableStateOf(PairingTab.JOIN) }
    var code by remember { mutableStateOf("") }
    var createdCode by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }

    val auth = FirebaseAuth.getInstance()
    val db = FirebaseFirestore.getInstance()
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Family Pairing") },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp)
        ) {
            Text(
                "Connect with your family by joining an existing code or creating a new one.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(20.dp))

            TabRow(selectedTabIndex = tab.ordinal) {
                Tab(
                    selected = tab == PairingTab.JOIN,
                    onClick = { tab = PairingTab.JOIN; message = "" },
                    text = { Text("Join Family") }
                )
                Tab(
                    selected = tab == PairingTab.CREATE,
                    onClick = { tab = PairingTab.CREATE; message = "" },
                    text = { Text("Create Family") }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            if (tab == PairingTab.JOIN) {
                Text("Enter the 6-digit code shared by your family.")

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = code,
                    onValueChange = {
                        code = it.filter { char -> char.isDigit() }.take(6)
                        message = ""
                    },
                    label = { Text("Family Code") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val uid = auth.currentUser?.uid
                        if (uid == null) {
                            isError = true
                            message = "Please log in first."
                            return@Button
                        }
                        if (code.length != 6) {
                            isError = true
                            message = "Please enter a 6-digit code."
                            return@Button
                        }

                        loading = true
                        message = ""

                        scope.launch {
                            try {
                                val family = db.collection("families").document(code).get().await()

                                if (!family.exists()) {
                                    isError = true
                                    message = "Family code not found."
                                    return@launch
                                }

                                db.collection("users").document(uid).update("familyId", code).await()

                                val profile = repo.getUserProfile(uid)
                                isError = false
                                message = "Family joined successfully!"

                                if (profile != null) {
                                    onPairingComplete(profile)
                                }
                            } catch (e: Exception) {
                                isError = true
                                message = e.message ?: "Could not join family."
                            } finally {
                                loading = false
                            }
                        }
                    },
                    enabled = !loading,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (loading) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = MaterialTheme.colorScheme.onPrimary)
                        Spacer(modifier = Modifier.width(10.dp))
                    }
                    Text(if (loading) "Joining..." else "Join Family")
                }
            } else {
                Text("We'll generate a unique 6-digit code you can share with your family.")

                Spacer(modifier = Modifier.height(16.dp))

                createdCode?.let { generated ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                "Your Family Code",
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                generated,
                                fontSize = 34.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 6.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedButton(onClick = { clipboard.setText(AnnotatedString(generated)) }) {
                                Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Copy Code")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }

                Button(
                    onClick = {
                        val uid = auth.currentUser?.uid
                        if (uid == null) {
                            isError = true
                            message = "Please log in first."
                            return@Button
                        }

                        loading = true
                        message = ""

                        scope.launch {
                            try {
                                val newCode = repo.createFamilyCode()
                                db.collection("users").document(uid).update("familyId", newCode).await()

                                createdCode = newCode
                                isError = false
                                message = "Family created! Share this code with your family."

                                val profile = repo.getUserProfile(uid)
                                if (profile != null) {
                                    onPairingComplete(profile)
                                }
                            } catch (e: Exception) {
                                isError = true
                                message = e.message ?: "Could not create family."
                            } finally {
                                loading = false
                            }
                        }
                    },
                    enabled = !loading,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (loading) "Creating..." else "Create Family Code")
                }
            }

            if (message.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    message,
                    color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}
