@file:OptIn(ExperimentalMaterial3Api::class)

package com.familypulse.app.ui.profile

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.familypulse.app.data.FirebaseRepository
import com.familypulse.app.models.UserProfile
import kotlinx.coroutines.launch

@Composable
fun ProfileScreen(
    repo: FirebaseRepository,
    onBack: () -> Unit,
    onLogout: () -> Unit
) {
    val scope = rememberCoroutineScope()

    var profile by remember { mutableStateOf<UserProfile?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }

    fun loadProfile() {
        scope.launch {
            loading = true
            error = ""

            try {
                val uid = repo.getCurrentUser()?.uid

                if (uid != null) {
                    profile = repo.getUserProfile(uid)
                } else {
                    error = "Please log in again."
                }
            } catch (e: Exception) {
                error = e.message ?: "Could not load profile."
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) { loadProfile() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Profile") },
                navigationIcon = { TextButton(onClick = onBack) { Text("Back") } }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
        ) {
            when {
                loading -> {
                    Box(modifier = Modifier.fillMaxWidth().padding(vertical = 60.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }

                error.isNotBlank() -> {
                    Text(text = error, color = MaterialTheme.colorScheme.error)
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedButton(onClick = { loadProfile() }) { Text("Try Again") }
                }

                profile != null -> {
                    val currentProfile = profile!!

                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Surface(
                            modifier = Modifier.size(84.dp),
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = currentProfile.name.firstOrNull()?.uppercase() ?: "?",
                                    style = MaterialTheme.typography.headlineLarge,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            currentProfile.name.ifBlank { "Family Member" },
                            style = MaterialTheme.typography.headlineSmall
                        )

                        Text(
                            currentProfile.email,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            ProfileRow(
                                label = "Role",
                                value = currentProfile.role,
                                valueColor = MaterialTheme.colorScheme.primary
                            )

                            Divider(modifier = Modifier.padding(vertical = 14.dp))

                            ProfileRow(
                                label = "Family",
                                value = currentProfile.familyId.ifBlank { "Not paired" }
                            )

                            Divider(modifier = Modifier.padding(vertical = 14.dp))

                            ProfileRow(
                                label = "Privacy Consent",
                                value = if (currentProfile.hasConsented) "Consent enabled" else "Consent not recorded",
                                valueColor = if (currentProfile.hasConsented)
                                    MaterialTheme.colorScheme.tertiary
                                else
                                    MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    OutlinedButton(onClick = { loadProfile() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Refresh Profile")
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    TextButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) {
                        Text("Logout", color = MaterialTheme.colorScheme.error)
                    }
                }

                else -> {
                    Text("Profile not found.")
                }
            }
        }
    }
}

@Composable
private fun ProfileRow(
    label: String,
    value: String,
    valueColor: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.Unspecified
) {
    Column {
        Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(modifier = Modifier.height(4.dp))
        Text(value, style = MaterialTheme.typography.titleMedium, color = valueColor)
    }
}
