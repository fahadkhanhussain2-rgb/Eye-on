package com.familypulse.app.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp

private val LightColors = lightColorScheme(
    primary = Color(0xFF3157D5),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDEE4FF),
    onPrimaryContainer = Color(0xFF0E1C63),
    secondary = Color(0xFF536DCC),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE3E8FF),
    onSecondaryContainer = Color(0xFF1B2559),
    tertiary = Color(0xFF1F9E6D),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFD4F5E3),
    onTertiaryContainer = Color(0xFF0A3D25),
    error = Color(0xFFBA1A1A),
    onError = Color.White,
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    background = Color(0xFFF7F8FC),
    onBackground = Color(0xFF171923),
    surface = Color.White,
    onSurface = Color(0xFF171923),
    surfaceVariant = Color(0xFFE5E7F0),
    onSurfaceVariant = Color(0xFF5A5D6B),
    outline = Color(0xFFC8CAD8),
    outlineVariant = Color(0xFFE0E2ED)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9EAEFF),
    onPrimary = Color(0xFF10214F),
    primaryContainer = Color(0xFF263B85),
    onPrimaryContainer = Color(0xFFDEE4FF),
    secondary = Color(0xFFB8C2FF),
    onSecondary = Color(0xFF1B2559),
    secondaryContainer = Color(0xFF303E7D),
    onSecondaryContainer = Color(0xFFE3E8FF),
    tertiary = Color(0xFF7FDCAE),
    onTertiary = Color(0xFF04381F),
    tertiaryContainer = Color(0xFF0F5636),
    onTertiaryContainer = Color(0xFFD4F5E3),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    background = Color(0xFF10131C),
    onBackground = Color(0xFFE7E8F2),
    surface = Color(0xFF191D28),
    onSurface = Color(0xFFE7E8F2),
    surfaceVariant = Color(0xFF2A2E3D),
    onSurfaceVariant = Color(0xFFB8BACA),
    outline = Color(0xFF474A5A),
    outlineVariant = Color(0xFF333645)
)

private val FamilyPulseShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

private val FamilyPulseTypography = Typography(
    headlineLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 30.sp, lineHeight = 36.sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.Bold, fontSize = 26.sp, lineHeight = 32.sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 28.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 19.sp, lineHeight = 24.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 16.sp, lineHeight = 22.sp),
    titleSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 13.sp, lineHeight = 18.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 14.sp)
)

@Composable
fun FamilyPulseTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = FamilyPulseTypography,
        shapes = FamilyPulseShapes,
        content = content
    )
}

@Composable
fun FamilyPulseLogo(size: Dp) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "FP",
            color = MaterialTheme.colorScheme.onPrimary,
            fontSize = (size.value * 0.34f).sp,
            fontWeight = FontWeight.Bold
        )
    }
}
